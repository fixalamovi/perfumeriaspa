-- V2: Datos iniciales con passwords BCrypt correctos

INSERT INTO roles (nombre, descripcion) VALUES
('ADMIN', 'Administrador del sistema con acceso total'),
('VENDEDOR', 'Vendedor con acceso a productos y pedidos'),
('CLIENTE', 'Cliente con acceso a sus propios datos');

INSERT INTO usuarios (username, password, email, nombre, apellido, activo, rol_id, fecha_creacion) VALUES
('admin',    '$2b$10$q13o4oyGAVm4okQPTF1QEe33keZUHi96jgbvl9LAx4HbRWH/cR7ty', 'admin@perfumeria.cl',    'Admin',   'Sistema',  1, 1, '2026-01-01'),
('vendedor', '$2b$10$iQHpjI2nXmTCx1V2UAXsRe96dQiR.3j5460Gdl7AvniwmrSPwzhN.', 'vendedor@perfumeria.cl', 'Carlos',  'González', 1, 2, '2026-01-01'),
('cliente',  '$2b$10$NySo0cLrPQYrA44mUMEWsOa0aZTuGK09PqirNtaSt67nszwkodpVq', 'cliente@perfumeria.cl',  'María',   'López',    1, 3, '2026-01-01');
