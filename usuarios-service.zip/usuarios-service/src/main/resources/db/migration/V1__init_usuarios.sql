-- V1: Esquema de usuarios

CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE,
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    apellido TEXT NOT NULL,
    activo INTEGER NOT NULL DEFAULT 1,
    rol_id INTEGER NOT NULL,
    fecha_creacion TEXT NOT NULL,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
);
