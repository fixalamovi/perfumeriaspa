package com.example.usuarios.controller;

import com.example.usuarios.exception.ReglaNegocioException;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.RolRepository;
import com.example.usuarios.repository.UsuarioRepository;
import com.example.usuarios.security.JwtUtil;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
        log.info("Intento de login para: {}", request.getUsername());

        Usuario usuario = usuarioRepository.findByUsername(request.getUsername())
            .orElse(null);

        if (usuario == null || !passwordEncoder.matches(request.getPassword(), usuario.getPassword())) {
            log.warn("Credenciales inválidas para: {}", request.getUsername());
            return ResponseEntity.status(401).body(
                Map.of("error", "Credenciales inválidas", "status", 401)
            );
        }

        if (!usuario.getActivo()) {
            return ResponseEntity.status(403).body(
                Map.of("error", "Usuario inactivo", "status", 403)
            );
        }

        String rolNombre = rolRepository.findById(usuario.getRolId())
            .map(r -> r.getNombre())
            .orElse("CLIENTE");

        String token = jwtUtil.generateToken(usuario.getUsername(), rolNombre);
        log.info("Login exitoso para: {}, rol: {}", usuario.getUsername(), rolNombre);

        return ResponseEntity.ok(Map.of(
            "token", token,
            "username", usuario.getUsername(),
            "nombre", usuario.getNombre(),
            "role", rolNombre,
            "type", "Bearer"
        ));
    }

    @Data
    public static class LoginRequest {
        @NotBlank(message = "El username es obligatorio")
        private String username;
        @NotBlank(message = "La contraseña es obligatoria")
        private String password;
    }
}
