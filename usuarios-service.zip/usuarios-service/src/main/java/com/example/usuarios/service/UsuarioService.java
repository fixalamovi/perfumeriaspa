package com.example.usuarios.service;

import com.example.usuarios.exception.RecursoNoEncontradoException;
import com.example.usuarios.exception.ReglaNegocioException;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository repository;
    private final PasswordEncoder passwordEncoder;

    public List<Usuario> obtenerTodos() {
        log.info("Listando todos los usuarios");
        return repository.findAll();
    }

    public Usuario obtenerPorId(Long id) {
        log.debug("Buscando usuario con id: {}", id);
        return repository.findById(id)
            .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con id: " + id));
    }

    public Usuario obtenerPorEmail(String email) {
        return repository.findByEmail(email)
            .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con email: " + email));
    }

    public Usuario obtenerPorUsername(String username) {
        return repository.findByUsername(username)
            .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado: " + username));
    }

    public List<Usuario> obtenerActivos() {
        return repository.findByActivo(true);
    }

    public List<Usuario> obtenerPorRol(Long rolId) {
        return repository.findByRolId(rolId);
    }

    public Usuario crear(Usuario usuario) {
        if (repository.existsByUsername(usuario.getUsername())) {
            throw new ReglaNegocioException("Ya existe un usuario con username: " + usuario.getUsername());
        }
        if (repository.existsByEmail(usuario.getEmail())) {
            throw new ReglaNegocioException("Ya existe un usuario con email: " + usuario.getEmail());
        }
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        usuario.setFechaCreacion(LocalDate.now().toString());
        usuario.setActivo(true);

        Usuario guardado = repository.save(usuario);
        log.info("Usuario creado con id: {}, username: {}", guardado.getId(), guardado.getUsername());
        return guardado;
    }

    public Usuario actualizar(Long id, Usuario usuarioActualizado) {
        Usuario existente = obtenerPorId(id);

        if (!existente.getEmail().equals(usuarioActualizado.getEmail())
                && repository.existsByEmail(usuarioActualizado.getEmail())) {
            throw new ReglaNegocioException("El email ya está en uso: " + usuarioActualizado.getEmail());
        }

        existente.setNombre(usuarioActualizado.getNombre());
        existente.setApellido(usuarioActualizado.getApellido());
        existente.setEmail(usuarioActualizado.getEmail());
        existente.setRolId(usuarioActualizado.getRolId());
        existente.setActivo(usuarioActualizado.getActivo());

        log.info("Usuario actualizado con id: {}", id);
        return repository.save(existente);
    }

    public void desactivar(Long id) {
        Usuario existente = obtenerPorId(id);
        existente.setActivo(false);
        repository.save(existente);
        log.info("Usuario desactivado con id: {}", id);
    }

    public void eliminar(Long id) {
        Usuario existente = obtenerPorId(id);
        repository.delete(existente);
        log.info("Usuario eliminado con id: {}", id);
    }
}
