package com.example.usuarios.service;

import com.example.usuarios.exception.RecursoNoEncontradoException;
import com.example.usuarios.exception.ReglaNegocioException;
import com.example.usuarios.model.Rol;
import com.example.usuarios.repository.RolRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RolService {

    private final RolRepository repository;

    public List<Rol> obtenerTodos() {
        return repository.findAll();
    }

    public Rol obtenerPorId(Long id) {
        return repository.findById(id)
            .orElseThrow(() -> new RecursoNoEncontradoException("Rol no encontrado con id: " + id));
    }

    public Rol crear(Rol rol) {
        if (repository.existsByNombre(rol.getNombre())) {
            throw new ReglaNegocioException("Ya existe un rol con nombre: " + rol.getNombre());
        }
        Rol guardado = repository.save(rol);
        log.info("Rol creado: {}", guardado.getNombre());
        return guardado;
    }

    public Rol actualizar(Long id, Rol rolActualizado) {
        Rol existente = obtenerPorId(id);
        existente.setNombre(rolActualizado.getNombre());
        existente.setDescripcion(rolActualizado.getDescripcion());
        log.info("Rol actualizado con id: {}", id);
        return repository.save(existente);
    }

    public void eliminar(Long id) {
        Rol existente = obtenerPorId(id);
        repository.delete(existente);
        log.info("Rol eliminado con id: {}", id);
    }
}
